THERAGENX Groq completion-token fix

Replace:
- extraction/provider/GroqProvider.java
- extraction/ExtractionService.java

Changes:
- Sends max_completion_tokens (default 1800) to Groq explicitly.
- Uses the same completion reserve for TPM reservation and chunk sizing.
- Reduces chunk size so the request leaves room for the JSON response envelope.

Configuration (application.properties):
app.groq.max-completion-tokens=1800
app.groq.rate-limit.completion-reserve-tokens=1800
app.groq.request.max-input-tokens=6200

Keep max_completion_tokens and completion-reserve-tokens equal. With configured TPM 8000 and safety ratio 0.95, the application may split documents into more chunks to stay within the safe rolling budget.

This ZIP was generated from the uploaded extraction package. A full Maven build could not be run because the complete project was not included.
